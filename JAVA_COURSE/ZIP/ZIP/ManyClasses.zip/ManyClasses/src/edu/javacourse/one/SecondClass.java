package edu.javacourse.one;

import edu.javacourse.many.ResearchClass;

public class SecondClass
{

    public void testInternal() {
        ResearchClass.InternalStaticFour inStFour = new ResearchClass.InternalStaticFour();
    }
}
