package edu.javacourse.many;

import edu.javacourse.many.ResearchClass.InternalThree;

public class FirstClass
{

    public void testInternal() {
        ResearchClass.InternalStaticTwo inStTwo = new ResearchClass.InternalStaticTwo();
        ResearchClass.InternalStaticThree inStThree = new ResearchClass.InternalStaticThree();
        ResearchClass.InternalStaticFour inStFour = new ResearchClass.InternalStaticFour();
    }
}
