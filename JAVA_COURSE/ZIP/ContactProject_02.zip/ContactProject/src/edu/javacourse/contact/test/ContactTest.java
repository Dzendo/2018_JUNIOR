package edu.javacourse.contact.test;

import edu.javacourse.contact.gui.ContactFrame;

/**
 * Класс для запуска тестовых вызовов
 */
public class ContactTest 
{
    public static void main(String[] args) {
        ContactFrame cf = new ContactFrame();
        cf.setVisible(true);
    }
}
