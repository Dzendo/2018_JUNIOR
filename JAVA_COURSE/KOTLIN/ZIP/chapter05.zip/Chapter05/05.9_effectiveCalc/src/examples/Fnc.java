/*
 * Fnc.java
 *
 * Created on April 9, 2007, 11:44 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package examples;

/**
 *
 * @author monakhov
 */
public class Fnc {
    
    /** Creates a new instance of Fnc */
    public Fnc() {
        super();
    }
    
    public long f(long i) {
       return i;
    }
    
}
