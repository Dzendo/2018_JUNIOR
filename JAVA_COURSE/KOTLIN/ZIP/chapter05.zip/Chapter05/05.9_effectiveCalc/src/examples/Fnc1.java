/*
 * FncX2.java
 *
 * Created on April 9, 2007, 11:46 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package examples;

/**
 *
 * @author monakhov
 */
public class Fnc1 extends Fnc{
    
    /** Creates a new instance of FncX2 */
    public Fnc1() {
        super();
    }

    public long f(long i) {
       return 1L;
    }
}
