/*
 * FncX2.java
 *
 * Created on April 9, 2007, 11:46 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package examples;

/**
 *
 * @author monakhov
 */
public class FncI2 extends Fnc{
    
    /** Creates a new instance of FncX2 */
    public FncI2() {
        super();
    }

    public long f(long i) {
       return i*i; 
    }
}
