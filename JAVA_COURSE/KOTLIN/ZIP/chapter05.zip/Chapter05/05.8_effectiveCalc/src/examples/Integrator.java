/*
 * Integrator.java
 *
 * Created on April 9, 2007, 1:28 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package examples;

/**
 *
 * @author monakhov
 */



public class Integrator {
    
public double result=0; 
public int activeThreadsCount=0; 
    /**
     * Creates a new instance of Integrator
     */
    public Integrator() {
      super();
    }
    
}
