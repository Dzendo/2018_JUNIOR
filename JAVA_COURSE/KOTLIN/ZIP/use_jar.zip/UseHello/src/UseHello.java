import edu.javacourse.jar.SayHello;

public class UseHello
{
    public static void main(String[] args) {
        SayHello sh = new SayHello();
        sh.sayHello();
    }
}