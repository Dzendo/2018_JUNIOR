package edu.javacourse.jar;

public class SayHello
{
    public void sayHello() {
        System.out.println("HELLO");
    }
}
