package com.example.velic.day_05_2x_startactivityforresust

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity_x : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_x)
    }
}
