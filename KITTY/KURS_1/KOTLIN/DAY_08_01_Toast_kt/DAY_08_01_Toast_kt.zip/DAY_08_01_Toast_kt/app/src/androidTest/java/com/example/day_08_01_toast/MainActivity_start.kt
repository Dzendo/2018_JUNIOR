package com.example.day_08_01_toast

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity_start : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
