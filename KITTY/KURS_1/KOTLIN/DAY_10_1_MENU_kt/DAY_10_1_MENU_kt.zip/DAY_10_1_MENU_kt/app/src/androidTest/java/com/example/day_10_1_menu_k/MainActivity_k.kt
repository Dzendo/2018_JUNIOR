package com.example.day_10_1_menu_k

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity_k : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
