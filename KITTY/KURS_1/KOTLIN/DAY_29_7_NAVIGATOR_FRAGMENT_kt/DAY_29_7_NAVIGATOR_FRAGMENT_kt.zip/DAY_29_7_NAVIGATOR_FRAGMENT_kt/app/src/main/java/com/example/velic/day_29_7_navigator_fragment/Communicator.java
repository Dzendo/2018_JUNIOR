package com.example.velic.day_29_7_navigator_fragment;

public interface Communicator {
    public void count(String data);
}
