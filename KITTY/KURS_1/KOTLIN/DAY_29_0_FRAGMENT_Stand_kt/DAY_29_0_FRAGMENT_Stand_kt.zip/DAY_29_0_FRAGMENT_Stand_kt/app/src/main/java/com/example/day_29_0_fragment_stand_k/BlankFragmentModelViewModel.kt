package com.example.day_29_0_fragment_stand_k

import androidx.lifecycle.ViewModel;

class BlankFragmentModelViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
