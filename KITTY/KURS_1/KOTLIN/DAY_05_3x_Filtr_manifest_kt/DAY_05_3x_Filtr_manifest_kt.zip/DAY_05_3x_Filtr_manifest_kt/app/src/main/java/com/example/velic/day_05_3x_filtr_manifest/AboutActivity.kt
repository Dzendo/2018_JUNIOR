package com.example.velic.day_05_3x_filtr_manifest

import android.app.Activity
import android.os.Bundle


class AboutActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.actyvity_about)
    }

}

