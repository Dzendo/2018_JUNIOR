package com.example.day_11_01_popupmenu_k

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity_kt : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
