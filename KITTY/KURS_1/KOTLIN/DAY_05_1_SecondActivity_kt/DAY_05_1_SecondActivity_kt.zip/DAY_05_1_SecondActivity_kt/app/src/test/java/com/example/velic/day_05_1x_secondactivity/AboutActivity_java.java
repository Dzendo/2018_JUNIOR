package com.example.velic.day_05_1x_secondactivity;

import android.app.Activity;
import android.os.Bundle;

public class AboutActivity_java extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actyvity_about);
    }

}

