package com.example.day_29_5_fragment_communicator_k;

public interface Communicator_java {
    public void count(String data);
}
