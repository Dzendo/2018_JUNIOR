gson.dwarves
============

Example code for Habrahabr. article.
